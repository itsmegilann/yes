
  # E-Commerce Homepage Mockup - Gilann Richbert U. Reyes

  This is a code bundle for E-Commerce Homepage Mockup - Gilann Richbert U. Reyes. The original project is available at https://www.figma.com/design/G81HIZw2e9g8BqSifc0iF2/E-Commerce-Homepage-Mockup---Gilann-Richbert-U.-Reyes.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  