import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent } from "./ui/card";

export function Newsletter() {
  return (
    <section className="w-full py-16 px-4 lg:px-32">
      <div className="max-w-[1440px] mx-auto flex justify-center">
        <Card className="w-full max-w-2xl">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl lg:text-3xl font-bold mb-4">
              Join our newsletter
            </h2>
            <p className="text-muted-foreground mb-6 text-lg">
              Get 10% off your first order and stay updated with our latest deals
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input
                type="email"
                placeholder="Enter your email address"
                className="flex-1"
              />
              <Button className="sm:w-auto">
                Subscribe
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-4">
              We respect your privacy. Unsubscribe at any time.
            </p>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}