export function AboutSection() {
  return (
    <section id="about" className="w-full py-16 px-4 lg:px-32 bg-white">
      <div className="max-w-[1440px] mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">About ShopSmart</h2>
          <p className="text-muted-foreground text-lg max-w-3xl mx-auto">
            We're passionate about bringing you the latest trends in fashion and lifestyle. 
            Since our founding, we've been committed to offering high-quality products at 
            affordable prices, with exceptional customer service every step of the way.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div className="p-6">
            <div className="text-4xl font-bold text-primary mb-2">10K+</div>
            <h3 className="font-medium mb-2">Happy Customers</h3>
            <p className="text-muted-foreground">Trusted by thousands of satisfied shoppers</p>
          </div>
          
          <div className="p-6">
            <div className="text-4xl font-bold text-primary mb-2">500+</div>
            <h3 className="font-medium mb-2">Products</h3>
            <p className="text-muted-foreground">Curated selection of trendy items</p>
          </div>
          
          <div className="p-6">
            <div className="text-4xl font-bold text-primary mb-2">24/7</div>
            <h3 className="font-medium mb-2">Support</h3>
            <p className="text-muted-foreground">Always here when you need us</p>
          </div>
        </div>
      </div>
    </section>
  );
}