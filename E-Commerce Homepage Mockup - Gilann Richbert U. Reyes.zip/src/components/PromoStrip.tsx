import { Truck, Shield, Headphones } from "lucide-react";

export function PromoStrip() {
  const benefits = [
    {
      icon: Truck,
      title: "Free Shipping",
      description: "On orders over ₱1,500"
    },
    {
      icon: Shield,
      title: "Secure Checkout",
      description: "100% secure payment"
    },
    {
      icon: Headphones,
      title: "24/7 Support",
      description: "Dedicated customer service"
    }
  ];

  return (
    <section className="w-full bg-primary py-8 px-4 lg:px-32">
      <div className="max-w-[1440px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => {
            const IconComponent = benefit.icon;
            return (
              <div key={index} className="flex items-center justify-center space-x-4 text-primary-foreground">
                <IconComponent className="h-8 w-8" />
                <div>
                  <h3 className="font-medium">{benefit.title}</h3>
                  <p className="text-sm opacity-90">{benefit.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}