import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function HeroSection() {
  return (
    <section className="relative w-full h-[600px] overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1714046298190-7c33737ddc94?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW1tZXIlMjBmYXNoaW9uJTIwY29sbGVjdGlvbnxlbnwxfHx8fDE3NTgxMDM3Mzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Summer Fashion Collection"
          className="w-full h-full object-cover"
        />
        {/* Dark overlay for better text readability */}
        <div className="absolute inset-0 bg-black/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex items-center justify-center px-4 lg:px-32">
        <div className="max-w-[1440px] w-full">
          <div className="text-center text-white">
            <h1 className="text-5xl lg:text-6xl font-bold mb-4">
              Summer 2025 Collection
            </h1>
            <p className="text-xl lg:text-2xl mb-8 text-gray-200">
              Trendy styles. Big savings.
            </p>
            <Button 
              size="lg" 
              className="bg-white text-black hover:bg-gray-100 px-8 py-3 text-lg rounded-full"
            >
              Shop Now
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}